<?php
// Heading
$_['heading_title']     = 'sms';



// Column
$_['text_success']         = 'پيام شما با موفقيت ارسال شد!';
$_['text_default']         = 'پيش فرض';
$_['text_newsletter']      = 'کليه مشترکين خبرنامه';
$_['text_customer_all']    = 'تمامي مشتريان';
$_['text_customer_group']  = 'گروهای مشتری';
$_['text_customer']        = 'مشتری ها';
$_['text_affiliate_all']   = 'تمام همکاران';
$_['text_affiliate']       = 'همکاران';
$_['text_product']         = 'خریداران محصولات خاص';

// Entry
$_['entry_store']          = 'ارسال اس ام اس از:';
$_['entry_to']             = 'به :';
$_['entry_customer_group'] = 'گروه مشتری :';
$_['entry_customer']       = 'مشتری :';
$_['entry_affiliate']      = 'همکار :';
$_['entry_product']        = 'محصولات :<br /><span class="help">ارسال فقط به مشتریانی که این محصول را خریده اند.</span>';
$_['entry_subject']        = 'موضوع :';
$_['entry_message']        = 'پیام :';

// Entry

?>