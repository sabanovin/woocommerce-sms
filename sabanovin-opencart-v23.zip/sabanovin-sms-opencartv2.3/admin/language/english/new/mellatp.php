<?php
// Heading
$_['heading_title']     = 'پرداخت های انجام شده';

// Column
$_['column_order_no'] = 'شناسه سفارش';
$_['column_name']   = 'نام پرداخت کننده';
$_['column_email']     = 'ایمیل';
$_['column_telephone']   = 'تلفن';
$_['column_amount']        = 'مبلغ پرداختی(ریال)';
$_['column_ref']        = 'شماره تراکنش (salerefid)';
$_['column_msg']      = 'پیام واریز کننده';
$_['column_date_added']      = 'تاریخ پرداخت وجه';

// Entry

?>