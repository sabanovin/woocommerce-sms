<?php
// Heading
$_['heading_title']     = 'فیش های ثبت شده';



// Column
$_['column_order_no'] = 'شناسه سفارش';
$_['column_name']   = 'نام پرداخت کننده';
$_['column_email']     = 'ایمیل';
$_['column_telephone']   = 'تلفن';
$_['column_bank']        = 'نام بانک';
$_['column_payment']      = 'شیوه پرداخت';
$_['column_no_fish']      = 'شماره فیش یا 4رقم کارت';
$_['column_datap']      = 'تاریخ واریز';
$_['column_msg']      = 'پیام واریز کننده';
$_['column_date_added']      = 'تاریخ ثبت فیش';

// Entry

?>