=== Persian Woocommerce SMS ===
author: ووکامرس فارسی
Contributors: hannanstd,Persianscript
author URI: http://www.woocommerce.ir/
Donate link: http://www.woocommerce.ir/
plugin URI: http://forum.persianscript.ir/topic/16615-%D8%AA%D8%A7%D9%BE%DB%8C%DA%A9-%D9%BE%D8%B4%D8%AA%DB%8C%D8%A8%D8%A7%D9%86%DB%8C-%D9%86%D8%B3%D8%AE%D9%87-3-%D8%A7%D9%81%D8%B2%D9%88%D9%86%D9%87-%D9%BE%DB%8C%D8%A7%D9%85%DA%A9-%D9%88%D9%88%DA%A9%D8%A7%D9%85%D8%B1%D8%B3/
Tags: woocommerce, commerce, e-commerce, commerce, shop, virtual shop, sms, sms notifications, iran, persian, farsi,woocommerce persian, e-commerce, ووکامرس, ووکامرس فارسی,woocommerce sms
Requires at least: 4.0
Tested up to: 4.9

ارسال پیامک به مشتریان در سیستم فروشگاه ساز ووکامرس

== Description ==
**Persian Woocommerce SMS** نام یک افزونه کاربردی برای سیستم فروشگاه ساز رایگان ووکامرس می باشد که شما را قادر می سازد تا براحتی اقدام به اطلاع رسانی از طریق پیامک به کاربرانتان کنید.

* مدیر فروشگاه در هنگام دریافت سفارش جدید یک پیامک دریافت می کند و همچنین مشتریان در هنگام ارسال سفارش ، تغییر وضعیت سفارش و یا تکمیل وضعیت سفارش پیامک دریافت می کنند. قابل ذکر است این افزونه با آخرین نسخه وردپرس (4) و ووکامرس فارسی (2.2) سازگاری کامل دارد.
* شما برای شروع کار با پلاگین نیاز به یک پنل اس ام اس دارید. پیشنهاد ما استفاده از پنل اس ام اس ملی پیامک است. این سامانه 30% تخفیف با کد wcsms30 به مدیران سایت های وردپرس ارائه می‌دهد.[خرید پنل پیامک](http://www.melipayamak.com/)
= درگاه های پیامک =
 * SepehrITC.com
 * PanizSMS.com
 * MAX-SMS.ir
 * ParandSMS.com
 * GAMAPayamak.com
 * LimooSMS.com
 * SMSFa.net
 * Arad-SMS.ir
 * FaraPayamak.ir
 * TJP.ir
 * SMS.Niazpardaz.com
 * PayamAfraz.ir
 * YektaSMS.com
 * Relax.ir
 * SMS.Paaz.ir
 * SmsBefrest.ir
 * Yektatech.ir
 * Postgah.info
 * IdehPayam.com
 * Azaranpayamak.ir
 * SMS.IR
 * S1.Websms.ir
 * Manirani.ir
 * Payam-Resan.com
 * BakhtarPanel.com
 * Avalpayam.com
 * IranSmsServer.com
 * MeliPayamak.com
 * IPPanel.com
 * LoginPanel.IR
 * SMS.Nasimnet.ir
 * SmsHooshmand.com
 * SmsFor.ir
 * ChaparPanel.ir
 * FirstPayamak.ir
 * SMS.Netpaydar.com
 * Panel.SmsPishgaman.com
 * ParsianPayam.ir
 * Hostiran.com
 * IranSMS.co
 * Negins.com
 * Afe.ir
 * Aradpayamak.net
 * iSMS.ir
 * RazPayamak.com
 * MihanSMSCenter.ir
 * 0098SMS.com
 * SefidSMS.ir
 * Chapargah.ir
 * Hafezpayam.com
 * FarazSMS.com
 * MashhadHost.com
 * MehrPanel.ir
 * kianartpanel.ir
 * Kavenegar.com (بجای نام کاربری ApiKey را وارد کرده و کلمه عبور را خالی قرار دهید)
 * ParsGreen.com (به سفارش فرید پارسایی و گروه تجارت آنلاین پیشتا : راهنما امضای دیجیتال را بجای نام کاربری وارد نموده و کلمه عبور را خالی رها کنید)

= درگاه های تلگرام =
 * BakhtarPanel.com
 * IlamClub.IR
 
= امکانات =

* ارسال پیامک به مشتری در هنگام ثبت سفارش
* ارسال پیامک به مدیر در هنگام ثبت سفارش
* ارسال پیامک به مشتری و مدیر در صورت تغییر وضعیت سفارش
* قابلیت ارسال پیامک تکی از طریق افزونه
* قابلیت ارسال پیامک به مشتری از طریق صفحه سفارشات
* قابلیت افزودن فیلد به صفحه سفارش مبنی بر دریافت پیامک
* امکان تنظیم دریافت پیامک در وضعیت های مختلف سفارش (تکمیل شده ، معلق و...)
* قابلیت تغییر متن پیشفرض ارسال پیامک به مشتری و مدیر
* قابلیت تنظیم دریافت پیامک برای مدیر یا کاربر
* نمایش وضعیت ارسال پیامک در برگه جزئیات سفارش در قسمت توضیحات
= Support =
*  [Persian Support in woocommerce.ir](http://forum.persianscript.ir/topic/16615-%D8%AA%D8%A7%D9%BE%DB%8C%DA%A9-%D9%BE%D8%B4%D8%AA%DB%8C%D8%A8%D8%A7%D9%86%DB%8C-%D9%86%D8%B3%D8%AE%D9%87-3-%D8%A7%D9%81%D8%B2%D9%88%D9%86%D9%87-%D9%BE%DB%8C%D8%A7%D9%85%DA%A9-%D9%88%D9%88%DA%A9%D8%A7%D9%85%D8%B1%D8%B3/)
*  [پشتیبانی در ووکامرس فارسی](http://forum.persianscript.ir/topic/16615-%D8%AA%D8%A7%D9%BE%DB%8C%DA%A9-%D9%BE%D8%B4%D8%AA%DB%8C%D8%A8%D8%A7%D9%86%DB%8C-%D9%86%D8%B3%D8%AE%D9%87-3-%D8%A7%D9%81%D8%B2%D9%88%D9%86%D9%87-%D9%BE%DB%8C%D8%A7%D9%85%DA%A9-%D9%88%D9%88%DA%A9%D8%A7%D9%85%D8%B1%D8%B3/)

== Installation ==
1. Upload `persian-woocommerce-sms` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Complete Persian Woocommerce SMS Settings

== Frequently asked questions ==

= Where can I find more information and documentation about the plug-in? =

You can read complete documentations on the [woocommerce.ir](http://www.woocommerce.ir)


== Screenshots ==
1. Screen shot 1
2. Screen shot 2
3. Screen shot 3
4. Screen shot 4
5. Screen shot 5
6. Screen shot 6
7. Screen shot 7
8. Screen shot 8
9. Screen shot 9
10. Screen shot 10
11. Screen shot 11
12. Screen shot 12
13. Screen shot 13
14. Screen shot 14

== Changelog ==
= 3.6.7 =
* added new services
= 3.6.4 =
* افزوده شدن وبسرویس فراز اس ام اس
= 3.6.3 =
* افزوده شدن دو وبسرویس جدید
= 3.6.2 =
* رفع باگ
* اضافه شدن وب سرویس 0098SMS.com
* اضافه شدن وب سرویس SefidSMS.ir
= 3.6.1 =
رفع یک باگ کوچک در PHP5.4
= 3.6.0 =
بازنویسی و سازگاری با ووکامرس 3
= 3.5.6 =
اضافه شدن وبسرویس MihanSMSCenter.ir و رفع مشکل Kavenegar.com
= 3.5.5 =
اضافه شدن وبسرویس RazPayamak.com
= 3.5.4 =
تغییر آی پی برخی سامانه های پیامکی
= 3.5.3 =
اضافه شدن وبسرویس isms.ir
= 3.5.2 =
اضافه شدن وبسرویس Aradpayamak.net
= 3.5.1 =
اضافه شدن وبسرویس Negins.com
= 3.5.0 =
اضافه شدن وبسرویس afe.ir
= 3.4.9 =
اضافه شدن وبسرویس kavenegar.com
= 3.4.8 =
* تغییر در وبسرویس ParandSMS.ir و اضافه شدن وبسرویس Login.Niazpardaz.ir
= 3.4.7 =
* اضافه شدن یک فیلتر وردپرس به نام persian_woo_sms_content_replace
= 3.4.6 =
* اضافه شدن یک فیلتر وردپرس به نام persian_woo_sms_content
= 3.4.5 =
* رفع باگ و سازگاری با شماره موبایل های فارسی
= 3.4.4 =
* رفع مشکلات گزارش شده
= 3.4.3 =
* اضافه شدن سامانه iransms.co
= 3.4.2 =
* اضافه شدن سامانه parsianpayam.ir , hostiran.com
= 3.4.1 =
* اضافه شدن سامانه panel.smspishgaman.com
= 3.4.0 =
* اضافه شدن سامانه sms.netpaydar.com
= 3.3.9 =
* تغییرات در سامانه max-sms.ir
= 3.3.8 =
* اضافه شدن وب سرویس firstpayamak.ir
= 3.3.7 =
* اضافه شدن وب سرویس chaparpanel.ir
= 3.3.6 =
* تغییر جزیی در وبسرویس باخترپنل
* اضافه شدن وبسرویس SMSfor.ir
* رفع باگ
= 3.3.5 =
* سازگاری با پیش شماره های جدید نظیر 0901
= 3.3.4 =
* سازگاری با نسخه 2.5 فارسی ساز
= 3.3.3 =
* رفع باگ
= 3.3.2 =
* رفع باگ
= 3.3.1 =
* رفع باگ
* تغییر روش ارسال پیام رسان از وبسرویس به URL
= 3.3.0 =
* رفع باگ
* اضافه شدن وب سرویس smshooshmand.com
* اضافه شدن وب سرویس sms.nasimnet.ir
* تغییرات در sms.ir
= 3.2.9 =
* اضافه شدن وب سرویس panizsms.com
= 3.2.8 =
* اضافه شدن وب سرویس Loginpanel.ir , ilamclub.ir
= 3.2.7 =
* اضافه شدن وب سرویس IPPanel , MelliPayamak
= 3.2.6 =
* اضافه شدن وب سرویس IranSmsServer
= 3.2.5 =
* بروز رسانی sms.ir و عدم نیاز به تنظیم مجدد محصولات قدیمی برای مدیر محصول
= 3.2.1 =
* بهبود پیغام بعد از بروز رسانی در مدیریت وردپرس
= 3.2.0 =
* اضافه شدن قابلیت اتصال به تلگرام
* اضافه شدن وبسرویس جدید
* تغییرات داخلی پلاگین
= 3.1.0 =
* سازگاری با sms.ir
* سازگاری با idehpayam.com
* سازگاری با azaranpayamak.ir
* اضافه شدن payam-resan.com
* اضافه شدن s1.websms.ir
* اضافه شدن شورت کد های پیامکی کامل
* اضافه شدن قابلیت تعیین عنوان فیلد موبایل
* تعیین متن دلخواه برای وضعیت های مختلف خریدار , مدیر و مدیر محصول
* رفع مشکل ارسال پیامک به مشتری در صورت ساختن سفارش به صورت دستی از مدیریت
* قابلیت تغییر متن پیامک ها هنگام تغییر وضعیت سفارش از داخل صفحه سفارشات به صورت آیجکس
* تغییرات بنیادی ارسال پیامک از صفحه سفارشات
* بهبود فایل های استاتیک و جلوگیری از تداخل جیکوئری
= 3.0.3 =
* تغییر در وبسرویس LimooSMS
= 3.0.2 =
* بهبود متاباکس موجود در صفحه محصول
= 3.0.1 =
* بهبود رابط کاربری
* اضافه شدن 2 کد میانبر جدید
* هماهنگی با برخی وبسرویس ها
= 3.0.0 =
* بازنویسی کامل و اضافه کردن امکانات جدید
= 2.1.2 =
* تغییر نام وبسرویس پانیز پیامک به سپهر فناوران تدبیر سامان
= 2.1.1 =
* رفع باگ
= 2.1.0 =
* افزوده شده درگاه های جدید
* رفع مشکل ارسال وضعیت سفارش به صورت انگلیسی
= 2.0.11 =
* افزوده شده درگاه های جدید
= 2.0.10 =
* افزوده شده درگاه های جدید
= 2.0.9 =
* افزوده شده درگاه های جدید
= 2.0.8 =
* افزوده شدن درگاه پیامک جدید و رفع مشکل
= 2.0.6 =
* افزوده شدن درگاه های پیامک جدید
= 2.0.5 =
* افزوده شدن درگاه های پیامک جدید
= 2.0.4 =
* افزوده شدن درگاه های پیامک جدید
= 2.0.3 =
* افزوده شدن درگاه smsfa
= 2.0.2 =
* رفع باگ در مکث اس ام اس
= 2.0.1 =
* رفع چند باگ و افزودن 4 درگاه پیامک
= 2.0 =
* کد نویسی مجدد و افزوده شدن امکانات جدید
= 1.5 =
* رفع باگ
= 1.4 =
* رفع باگ
= 1.3 =
* اضافه شدن وبسرویس های جدید
= 1.0 =
* نسخه اولیه

== Upgrade Notice ==
= 3.6.7 =
* added kianartpanel.ir service

==Traducciones ==
You can read complete documentations on the [woocommerce.ir](http://www.woocommerce.ir)