<?php
header('Location: http://woocommerce.ir');exit; 
?>