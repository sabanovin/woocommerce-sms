<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{sabanovin}prestashop>sabanovin_e9d94696815e57458abea119dc887829'] = 'وب سرویس پیام کوتاه صبا نوین';
$_MODULE['<{sabanovin}prestashop>sabanovin_b8a052c6cbcb51b6b75ab9ab89f6f940'] = 'اطلاع رسانی ها از طریق وب سرویس پیام کوتاه صبا نوین';
$_MODULE['<{sabanovin}prestashop>sabanovin_876f23178c29dc2552c0b48bf23cd9bd'] = 'آیا مطمئن هستید که می خواهید حذف کنید؟';
$_MODULE['<{sabanovin}prestashop>sabanovin_f4f70727dc34561dfde1a3c529b6205c'] = 'تنظیمات';
$_MODULE['<{sabanovin}prestashop>sabanovin_cd10e42fd12bdcec5bb25a7c824080e2'] = 'کلید شناسایی (APIKey)';
$_MODULE['<{sabanovin}prestashop>sabanovin_8aace3ec18d83874d22850b7eee93c7d'] = 'شماره خط ارسال کننده';
$_MODULE['<{sabanovin}prestashop>sabanovin_5d6de9a334bffec8a9cb3a315963b390'] = 'شماره همراه مدیر سایت';
$_MODULE['<{sabanovin}prestashop>sabanovin_0c5ed2402dbe0955cc386ce85419a2f5'] = 'اطاع رسانی هنگام درج سفارش جدید(مدیر)';
$_MODULE['<{sabanovin}prestashop>sabanovin_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'فعال';
$_MODULE['<{sabanovin}prestashop>sabanovin_a65e4728d58ac76ac4c31867781cdb5d'] = 'قالب پیام ';
$_MODULE['<{sabanovin}prestashop>sabanovin_209126213edd5a174dae0a4b84b6869e'] = 'اطاع رسانی هنگام درج سفارش جدید(مشتری)';
$_MODULE['<{sabanovin}prestashop>sabanovin_68078f6effcba013bce8a95f741a957f'] = 'قالب پیام ';
$_MODULE['<{sabanovin}prestashop>sabanovin_75785d8004e59936d2753e9aca2bca94'] = 'اطاع رسانی هنگام تغییر وضعیت سفارش (مشتری)';
$_MODULE['<{sabanovin}prestashop>sabanovin_27e375686d86062ea3b2d3df2b16af75'] = 'قالب پیام ';
$_MODULE['<{sabanovin}prestashop>sabanovin_fc62eafbd4d854c018bdca73c29f9b46'] = 'اطاع رسانی هنگام ثبت نام مشتری جدید(مدیر)';
$_MODULE['<{sabanovin}prestashop>sabanovin_76513febc0df0a1dfd397d4d07caea02'] = 'قالب پیام ';
$_MODULE['<{sabanovin}prestashop>sabanovin_ab99cebe67c185bdf152bf72b3b7f594'] = 'قالب پیام ';
$_MODULE['<{sabanovin}prestashop>sabanovin_cd5db548a2109f8565610c852ee67078'] = 'اطاع رسانی هنگام ثبت نام مشتری جدید (مشتری)';
$_MODULE['<{sabanovin}prestashop>sabanovin_d4dccb8ca2dac4e53c01bd9954755332'] = 'ذخیره تنظیمات';
$_MODULE['<{sabanovin}prestashop>sabanovin_c9cc8cce247e49bae79f15173ce97354'] = 'ذخیره';
