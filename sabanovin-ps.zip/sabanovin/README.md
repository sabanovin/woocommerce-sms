Skebby PrestaShop module
---------------------------------------------------------------------

Copyright (C) 2014 https://www.skebby.it 

You can freely use this module in your PrestaShop e-commerce website.
Please send your questions & comments to supporto@skebby.com


Step 1)
Download the latest version of Skebby PrestaShop module from https://github.com/skebby/prestashop/releases/

Step 2)
Login to your PrestaShop admin panel (Back office).

Step 3)
Go to "Modules" tab and click the "Add a module from my computer" link.

Step 4)
Select the "Skebby.zip" file using the browse button from the "Module file" section and hit the upload button.

Step 5)
Go to modules tab, find Skebby module and click the 'configure' link.

Step 6)
Enjoy Skebby




