﻿# $Id: sms_templates.php $
# TomatoCart Open Source Shopping Cart Solutions
# http://www.tomatocart.com
#
# http://www.tomatoshop.ir Persian tomatocart by Ali Masooumi +masooumi@gmail.com
#
# Copyright (c) 2009-2010 Wuxi Elootec Technology Co., Ltd
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License v2 (1991)
# as published by the Free Software Foundation.
heading_title = قالب پیامک

table_heading_sms_template_name = نام قالب
table_heading_sms_title = عنوان پیام
table_heading_sms_template_status = وضعيت
table_heading_action = عمليات

heading_title_edit_sms_templates = ویرایش الگو
heading_title_data = تاريخ

field_sms_templates_name = نام الگو:
field_sms_templates_status = وضعیت الگوی پیامک:

status_disabled = غیر فعال
status_enabled = فعال

field_sms_title = عنوان پیامک:
field_sms_content = متن پیامک:
field_variables = متغيرها:

button_insert = افزودن

ms_error_sms_title_empty = لطفا عنوان پیامک را وارد نمایید.
ms_error_sms_content_empty = لطفا متن پیامک را وارد نمایید.

