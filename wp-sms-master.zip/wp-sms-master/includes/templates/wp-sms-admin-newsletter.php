<br>
<div class="update-nag">
    <form action="//wp-sms-plugin.us7.list-manage.com/subscribe/post?u=628dc1468c7c7db0ba42f0137&amp;id=a3914329f1"
          method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate"
          target="_blank" novalidate>
		<?php _e( 'Subscribe to our mailing list for get any news of the WP SMS plugin', 'wp-sms' ); ?>
        <input type="email" value="<?php bloginfo( 'admin_email' ); ?>" name="EMAIL" class="required email"
               id="mce-EMAIL">
        <input type="hidden" name="b_628dc1468c7c7db0ba42f0137_a3914329f1" tabindex="-1" value="">
        <input type="submit" value="<?php _e( 'Subscribe', 'wp-sms' ); ?>" name="subscribe" id="mc-embedded-subscribe"
               class="button">
        <a href="?page=wp-sms-settings&action=wpsms-hide-newsletter" class="button"><?php _e( 'Close', 'wp-sms' ); ?></a>
    </form>
</div>