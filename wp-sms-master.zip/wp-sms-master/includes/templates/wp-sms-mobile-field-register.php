<p>
    <label for="mobile"><?php _e( 'Your Mobile Number', 'wp-sms' ) ?><br/>
        <input type="text" name="mobile" id="mobile" class="input"
               value="<?php echo esc_attr( stripslashes( $mobile ) ); ?>" size="25"/></label>
</p>