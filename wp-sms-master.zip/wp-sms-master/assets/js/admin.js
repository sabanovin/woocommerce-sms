﻿jQuery(document).ready(function () {
    jQuery(".chosen-select").chosen();
});